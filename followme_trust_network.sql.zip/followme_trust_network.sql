-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 17, 2022 at 06:07 PM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.2.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `followme_trust_network`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_exam`
--

CREATE TABLE `tbl_exam` (
  `id` int(11) NOT NULL,
  `task_level_id` int(11) NOT NULL,
  `exam_title` varchar(100) DEFAULT NULL,
  `start_time` datetime DEFAULT NULL,
  `end_time` datetime DEFAULT NULL,
  `total_question` int(4) DEFAULT NULL,
  `create_date` datetime DEFAULT NULL,
  `update_date` datetime DEFAULT NULL,
  `status` enum('0','1') NOT NULL DEFAULT '1',
  `deleted` enum('0','1') NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_exam`
--

INSERT INTO `tbl_exam` (`id`, `task_level_id`, `exam_title`, `start_time`, `end_time`, `total_question`, `create_date`, `update_date`, `status`, `deleted`) VALUES
(1, 293, 'J C1 L2', '2021-11-09 21:19:00', '2021-11-08 21:19:00', 1, '2021-11-29 16:52:24', NULL, '1', '0'),
(2, 5, 'J C1 L1', '2021-11-02 21:23:00', '2021-11-24 21:23:00', 1, '2021-11-29 16:54:01', NULL, '1', '0'),
(3, 4, 'J C1 L1 2', '2021-11-12 21:23:00', '2021-12-31 21:23:00', 1, '2021-11-29 16:54:43', NULL, '1', '0'),
(4, 4, 'PHP Quiz for beginner PHP allows you to send emails directly from a script', '2021-11-29 21:26:00', '2021-12-31 22:26:00', 4, '2021-11-30 17:31:13', NULL, '0', '0'),
(5, 294, 'Som C1 S3', '2021-11-02 21:28:00', '2021-11-10 21:28:00', 1, '2021-11-29 16:59:08', NULL, '1', '0'),
(6, 4, 'Math exam', '2021-12-11 21:11:00', '2021-12-21 21:11:00', 2, '2021-12-12 16:46:34', NULL, '1', '0'),
(7, 295, 'General Awareness', '2021-12-12 20:47:00', '2021-12-15 20:47:00', 2, '2021-12-13 16:19:56', NULL, '1', '0');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_exam_given`
--

CREATE TABLE `tbl_exam_given` (
  `id` int(11) NOT NULL,
  `exam_id` int(11) NOT NULL,
  `task_level_id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL,
  `percentage_got` int(11) NOT NULL,
  `is_exam_pass` enum('Y','N') NOT NULL DEFAULT 'N',
  `exam_date` datetime DEFAULT NULL,
  `status` enum('0','1') NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_exam_given`
--

INSERT INTO `tbl_exam_given` (`id`, `exam_id`, `task_level_id`, `member_id`, `percentage_got`, `is_exam_pass`, `exam_date`, `status`) VALUES
(1, 7, 295, 27, 100, 'Y', '2021-12-13 16:29:12', '1');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_exam_given_answer`
--

CREATE TABLE `tbl_exam_given_answer` (
  `id` int(11) NOT NULL,
  `exam_given_id` int(11) NOT NULL,
  `exam_id` int(11) NOT NULL,
  `task_level_id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL,
  `exam_question_id` int(11) NOT NULL,
  `exam_answer` longtext DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_exam_given_answer`
--

INSERT INTO `tbl_exam_given_answer` (`id`, `exam_given_id`, `exam_id`, `task_level_id`, `member_id`, `exam_question_id`, `exam_answer`) VALUES
(1, 1, 7, 295, 27, 23, '{\"correct_ans\":2,\"options\":[{\"optionval\":\"Newyork\"},{\"optionval\":\"Delhi\"},{\"optionval\":\"Washington\"},{\"optionval\":\"Hongkong\"}],\"given_ans\":2}'),
(2, 1, 7, 295, 27, 24, '{\"correct_ans\":1,\"options\":[{\"optionval\":\"Brandon\"},{\"optionval\":\"zuckerberg\"},{\"optionval\":\"Ross Taylor\"},{\"optionval\":\"Nai sahw\"}],\"given_ans\":1}');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_exam_question`
--

CREATE TABLE `tbl_exam_question` (
  `id` int(11) NOT NULL,
  `exam_id` int(11) NOT NULL,
  `task_level_id` int(11) NOT NULL,
  `exam_question` text DEFAULT NULL,
  `exam_answer_option` longtext DEFAULT NULL,
  `is_deleted` enum('0','1') NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_exam_question`
--

INSERT INTO `tbl_exam_question` (`id`, `exam_id`, `task_level_id`, `exam_question`, `exam_answer_option`, `is_deleted`) VALUES
(1, 1, 293, 'gfg', '{\"correct_ans\":0,\"options\":[{\"optionval\":\"gfg\"},{\"optionval\":\"gfg\"},{\"optionval\":\"gfg\"},{\"optionval\":\"gfg\"}]}', '1'),
(2, 1, 293, 'gfg', '{\"correct_ans\":0,\"options\":[{\"optionval\":\"gfg\"},{\"optionval\":\"gfg\"},{\"optionval\":\"gfg\"},{\"optionval\":\"gfg\"}]}', '0'),
(3, 2, 5, 'aaa', '{\"correct_ans\":2,\"options\":[{\"optionval\":\"a\"},{\"optionval\":\"b\"},{\"optionval\":\"c\"},{\"optionval\":\"d\"}]}', '0'),
(4, 3, 5, 'wqwq', '{\"correct_ans\":0,\"options\":[{\"optionval\":\"j\"},{\"optionval\":\"k\"},{\"optionval\":\"l\"},{\"optionval\":\"m\"}]}', '0'),
(5, 4, 4, 'fd', '{\"correct_ans\":0,\"options\":[{\"optionval\":\"fd\"},{\"optionval\":\"fdf\"},{\"optionval\":\"fdf\"},{\"optionval\":\"fdf\"}]}', '1'),
(6, 4, 4, 'fd', '{\"correct_ans\":0,\"options\":[{\"optionval\":\"fd\"},{\"optionval\":\"fdf\"},{\"optionval\":\"fdf\"},{\"optionval\":\"fdf\"}]}', '1'),
(7, 5, 294, 'fdf', '{\"correct_ans\":0,\"options\":[{\"optionval\":\"fd\"},{\"optionval\":\"fdf\"},{\"optionval\":\"gfg\"},{\"optionval\":\"jhj\"}]}', '1'),
(8, 5, 294, 'fdf', '{\"correct_ans\":0,\"options\":[{\"optionval\":\"fd\"},{\"optionval\":\"fdf\"},{\"optionval\":\"gfg\"},{\"optionval\":\"jhj\"}]}', '0'),
(9, 4, 4, 'fd', '{\"correct_ans\":1,\"options\":[{\"optionval\":\"fd\"},{\"optionval\":\"fdf\"},{\"optionval\":\"fdf\"},{\"optionval\":\"fdf\"}]}', '1'),
(10, 4, 4, 'What does PHP stand for?', '{\"correct_ans\":2,\"options\":[{\"optionval\":\"Private Homr Page\"},{\"optionval\":\"Personal Hypertext Processor\"},{\"optionval\":\"PHP: Hypertext processor\"}]}', '1'),
(11, 4, 4, 'The PHP syntax is most similar to', '{\"correct_ans\":3,\"options\":[{\"optionval\":\"VbScript\"},{\"optionval\":\"javaScript\"},{\"optionval\":\"Pearl\"},{\"optionval\":\"PHP\"}]}', '1'),
(12, 4, 4, 'When using the POST method, variables are displayed in the URL:', '{\"correct_ans\":0,\"options\":[{\"optionval\":\"False\"},{\"optionval\":\"True\"}]}', '1'),
(13, 4, 4, 'What does PHP stand for?', '{\"correct_ans\":2,\"options\":[{\"optionval\":\"Private Homr Page\"},{\"optionval\":\"Personal Hypertext Processor\"},{\"optionval\":\"PHP: Hypertext processor\"}]}', '1'),
(14, 4, 4, 'The PHP syntax is most similar to', '{\"correct_ans\":3,\"options\":[{\"optionval\":\"VbScript\"},{\"optionval\":\"javaScript\"},{\"optionval\":\"Pearl\"},{\"optionval\":\"PHP\"}]}', '1'),
(15, 4, 4, 'When using the POST method, variables are displayed in the URL:', '{\"correct_ans\":0,\"options\":[{\"optionval\":\"False\"},{\"optionval\":\"True\"}]}', '1'),
(16, 4, 4, 'PHP allows you to send emails directly from a script', '{\"correct_ans\":1,\"options\":[{\"optionval\":\"False\"},{\"optionval\":\"True\"},{\"optionval\":\"May be\"},{\"optionval\":\"All Of the above\"}]}', '1'),
(17, 4, 4, 'What does PHP stand for?', '{\"correct_ans\":2,\"options\":[{\"optionval\":\"Private Homr Page\"},{\"optionval\":\"Personal Hypertext Processor\"},{\"optionval\":\"PHP: Hypertext processor\"}]}', '0'),
(18, 4, 4, 'The PHP syntax is most similar to', '{\"correct_ans\":3,\"options\":[{\"optionval\":\"VbScript\"},{\"optionval\":\"javaScript\"},{\"optionval\":\"Pearl\"},{\"optionval\":\"PHP\"}]}', '0'),
(19, 4, 4, 'When using the POST method, variables are displayed in the URL:', '{\"correct_ans\":0,\"options\":[{\"optionval\":\"False\"},{\"optionval\":\"True\"}]}', '0'),
(20, 4, 4, 'PHP allows you to send emails directly from a script', '{\"correct_ans\":1,\"options\":[{\"optionval\":\"False\"},{\"optionval\":\"True\"},{\"optionval\":\"May be\"},{\"optionval\":\"All Of the above\"}]}', '0'),
(21, 6, 4, 'What is the Capital of india.', '{\"correct_ans\":0,\"options\":[{\"optionval\":\"Delhi\"},{\"optionval\":\"Kolkata\"},{\"optionval\":\"Mumbai\"},{\"optionval\":\"Chennai\"}]}', '0'),
(22, 6, 4, 'Who is the owner of Facebook', '{\"correct_ans\":0,\"options\":[{\"optionval\":\"Steave Job\"},{\"optionval\":\"Mark Zuckerberg\"},{\"optionval\":\"Chage Babel\"},{\"optionval\":\"Ross tension\"}]}', '0'),
(23, 7, 295, 'What is the Captial Of Amreca', '{\"correct_ans\":2,\"options\":[{\"optionval\":\"Newyork\"},{\"optionval\":\"Delhi\"},{\"optionval\":\"Washington\"},{\"optionval\":\"Hongkong\"}]}', '0'),
(24, 7, 295, 'What is the name if Ceo if face book', '{\"correct_ans\":1,\"options\":[{\"optionval\":\"Brandon\"},{\"optionval\":\"zuckerberg\"},{\"optionval\":\"Ross Taylor\"},{\"optionval\":\"Nai sahw\"}]}', '0');

-- --------------------------------------------------------

--
-- Table structure for table `tn_age_group`
--

CREATE TABLE `tn_age_group` (
  `id` int(11) NOT NULL,
  `agegroup_name` varchar(100) DEFAULT NULL,
  `age_range` varchar(10) DEFAULT NULL,
  `min_age` int(4) DEFAULT NULL,
  `max_age` int(4) DEFAULT NULL,
  `agegroup_desc` mediumtext DEFAULT NULL,
  `create_date` datetime DEFAULT NULL,
  `update_date` datetime DEFAULT NULL,
  `status` enum('0','1') NOT NULL DEFAULT '1',
  `deleted` enum('0','1') NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tn_age_group`
--

INSERT INTO `tn_age_group` (`id`, `agegroup_name`, `age_range`, `min_age`, `max_age`, `agegroup_desc`, `create_date`, `update_date`, `status`, `deleted`) VALUES
(1, 'Teenager', '13-18', 13, 18, 'Teenager Desc', '2021-10-02 12:04:07', '2021-10-02 18:19:15', '1', '0'),
(2, 'Young Adults', '19-34', 19, 34, 'Young Adults Description', '2021-10-02 15:10:58', '2021-10-02 18:18:57', '1', '0'),
(3, 'Middle Age', '35-48', 35, 48, '', '2021-10-02 18:20:00', NULL, '1', '0'),
(4, 'Old Adults', '49-120', 49, 120, 'Old Adults Desc', '2021-10-02 18:20:17', NULL, '1', '0');

-- --------------------------------------------------------

--
-- Table structure for table `tn_group`
--

CREATE TABLE `tn_group` (
  `id` int(11) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `group_desc` mediumtext DEFAULT NULL,
  `create_date` datetime DEFAULT NULL,
  `update_date` datetime DEFAULT NULL,
  `status` enum('0','1') NOT NULL DEFAULT '1',
  `deleted` enum('0','1') NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tn_group`
--

INSERT INTO `tn_group` (`id`, `name`, `group_desc`, `create_date`, `update_date`, `status`, `deleted`) VALUES
(1, 'School Friends', 'Aasoomm khisdhfdfd', '2021-08-14 12:39:39', NULL, '1', '0'),
(2, 'College Friends', 'froend ddesc', '2021-08-14 12:53:24', NULL, '1', '0'),
(3, 'Friends', 'sas', '2021-08-14 13:03:26', NULL, '1', '0'),
(4, 'Prayer Friends', 'dsdsd', '2021-08-14 13:03:49', NULL, '0', '0');

-- --------------------------------------------------------

--
-- Table structure for table `tn_members`
--

CREATE TABLE `tn_members` (
  `id` int(11) NOT NULL,
  `parent_id` int(11) NOT NULL DEFAULT 0,
  `admin_id` int(11) NOT NULL DEFAULT 0,
  `agegroup_id` int(11) NOT NULL DEFAULT 0,
  `membership_type` enum('RM','CM','CC') DEFAULT NULL,
  `first_name` varchar(100) DEFAULT NULL,
  `last_name` varchar(100) DEFAULT NULL,
  `user_email` varchar(50) DEFAULT NULL,
  `type` int(4) NOT NULL DEFAULT 0,
  `trustee_board` varchar(255) DEFAULT NULL,
  `gender` varchar(4) DEFAULT NULL,
  `marital_status` varchar(12) DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `contact_person` varchar(255) DEFAULT NULL,
  `contact_mobile` varchar(20) DEFAULT NULL,
  `contact_alt_mobile` varchar(20) DEFAULT NULL,
  `alt_email` varchar(25) DEFAULT NULL,
  `website` varchar(120) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `country` int(11) NOT NULL DEFAULT 0,
  `state` int(11) NOT NULL DEFAULT 0,
  `city` int(11) NOT NULL DEFAULT 0,
  `postal_code` varchar(20) DEFAULT NULL,
  `profile_image` varchar(255) DEFAULT NULL,
  `cover_image` varchar(255) DEFAULT NULL,
  `notification_data` text DEFAULT NULL,
  `is_admin` enum('Y','N') NOT NULL DEFAULT 'N',
  `admin_create_date` datetime DEFAULT NULL,
  `is_approved` enum('Y','N') NOT NULL DEFAULT 'N',
  `create_date` datetime DEFAULT NULL,
  `update_date` datetime DEFAULT NULL,
  `status` enum('0','1') NOT NULL DEFAULT '1',
  `deleted` enum('0','1') NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tn_members`
--

INSERT INTO `tn_members` (`id`, `parent_id`, `admin_id`, `agegroup_id`, `membership_type`, `first_name`, `last_name`, `user_email`, `type`, `trustee_board`, `gender`, `marital_status`, `dob`, `contact_person`, `contact_mobile`, `contact_alt_mobile`, `alt_email`, `website`, `password`, `address`, `country`, `state`, `city`, `postal_code`, `profile_image`, `cover_image`, `notification_data`, `is_admin`, `admin_create_date`, `is_approved`, `create_date`, `update_date`, `status`, `deleted`) VALUES
(1, 0, 0, 0, 'CC', 'city-church', '', 'noreplycitychucrh@gmail.com', 9999, 'noreplycitychucrh', 'nore', NULL, NULL, NULL, NULL, '', NULL, NULL, '123456', '', 0, 0, 0, '', NULL, NULL, '{\"email_notify\":false,\"sms_notify\":false,\"email_on_new_notify\":false,\"email_on_direcr_msg\":false,\"email_on_add_cnction\":false,\"escalate_email_on_new_order\":false,\"escalate_email_on_new_member_approval\":false,\"escalate_email_on_member_registration\":false}', 'N', NULL, 'Y', '2021-08-17 15:49:56', '2021-08-17 17:09:15', '1', '0'),
(2, 0, 0, 0, 'CM', 'Pointo Church', '', 'pointo@gmail.com', 0, NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, '123456', '', 0, 0, 0, '', NULL, NULL, '{\"email_notify\":false,\"sms_notify\":false,\"email_on_new_notify\":false,\"email_on_direcr_msg\":false,\"email_on_add_cnction\":false,\"escalate_email_on_new_order\":false,\"escalate_email_on_new_member_approval\":false,\"escalate_email_on_member_registration\":false}', 'N', NULL, 'Y', '2021-08-17 15:49:56', '2021-08-17 17:09:15', '1', '0'),
(3, 0, 0, 0, 'CM', 'Velankanni Church', '', 'vela@gmail.com', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '123456', 'Champassari. pokijoteE', 101, 41, 5512, '704403', NULL, NULL, '{\"email_notify\":false,\"sms_notify\":false,\"email_on_new_notify\":false,\"email_on_direcr_msg\":false,\"email_on_add_cnction\":false,\"escalate_email_on_new_order\":false,\"escalate_email_on_new_member_approval\":false,\"escalate_email_on_member_registration\":false}', 'N', NULL, 'Y', '2021-08-17 16:00:19', '2021-08-19 19:34:42', '1', '0'),
(4, 0, 0, 0, 'CM', 'Parumala Church', '', '', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '123456', '35 GM Road; Behala', 0, 0, 0, '700034', NULL, NULL, '{\"email_notify\":false,\"sms_notify\":false,\"email_on_new_notify\":false,\"email_on_direcr_msg\":false,\"email_on_add_cnction\":false,\"escalate_email_on_new_order\":false,\"escalate_email_on_new_member_approval\":false,\"escalate_email_on_member_registration\":false}', 'N', NULL, 'N', '2021-08-17 17:12:42', '2021-08-20 06:17:08', '1', '0'),
(5, 0, 0, 0, 'CM', 'Basilica of Bom Jesus', '', 'admin@gmail.com', 1, 'trustee Board Goa', '', '', '2000-08-01', 'Father Jacob', '777777777777', '666666666666', 'jacon@father.com', 'http://www.basilicaofbomjesus.com', '123456', '45  Church Road ;Goa Panji', 101, 11, 749, '700001', '16296332993544.jpg', NULL, '{\"email_notify\":true,\"sms_notify\":true,\"email_on_new_notify\":false,\"email_on_direcr_msg\":true,\"email_on_add_cnction\":false,\"escalate_email_on_new_order\":false,\"escalate_email_on_new_member_approval\":true,\"escalate_email_on_member_registration\":false}', 'N', NULL, 'Y', '2021-08-21 19:57:24', '2021-08-27 20:21:34', '1', '0'),
(6, 5, 13, 0, 'RM', 'Tanushri 1', 'Kanu1', 'tanushri@gmail.com', 0, '', 'M', 'Married', '2000-01-18', '', '999999999999', '888888888888', 'somdeepalt@gmail.com', '', '123456', '34 GM Road; \nNear Senpally Auto Stand( SBI BANK)\nBehind New House\nBehala', 101, 41, 5583, '700034', '16296326857634.jpg', NULL, '{\"email_notify\":false,\"sms_notify\":false,\"email_on_new_notify\":false,\"email_on_direcr_msg\":false,\"email_on_add_cnction\":false,\"escalate_email_on_new_order\":false,\"escalate_email_on_new_member_approval\":false,\"escalate_email_on_member_registration\":false}', 'N', '2021-10-02 18:40:59', 'Y', '2021-08-21 20:00:42', '2021-08-22 13:52:16', '1', '0'),
(7, 5, 0, 2, 'RM', 'Somdeep-A', 'Kanu', 'somdeepkanu@gmail.com', 0, '', 'M', 'Married', '2021-08-01', '', '9804330891', '8013179998', 'somdeepalt@gmail.com', '', '123456', '35 GM Raod', 101, 41, 5583, '700035', '1631895714.png', NULL, '{\"email_notify\":true,\"sms_notify\":true,\"email_on_new_notify\":true,\"email_on_direcr_msg\":true,\"email_on_add_cnction\":true,\"escalate_email_on_new_order\":true,\"escalate_email_on_new_member_approval\":true,\"escalate_email_on_member_registration\":true}', 'Y', '2021-10-04 18:39:52', 'Y', '2021-08-28 05:25:51', '2021-09-17 18:21:54', '1', '0'),
(8, 2, 0, 1, 'RM', 'TanushriAdminPointo1', 'Kanu', 'tanushri1@gmail.com', 0, '', 'M', 'Married', '1980-08-18', '', '999999999999', '888888888888', 'somdeepalt@gmail.com', '', '123456', '34 GM Road; \nNear Senpally Auto Stand( SBI BANK)\nBehind New House\nBehala', 101, 41, 5583, '700034', '16296326857634.jpg', NULL, '{\"email_notify\":false,\"sms_notify\":false,\"email_on_new_notify\":false,\"email_on_direcr_msg\":false,\"email_on_add_cnction\":false,\"escalate_email_on_new_order\":false,\"escalate_email_on_new_member_approval\":false,\"escalate_email_on_member_registration\":false}', 'Y', '2021-10-04 18:00:09', 'Y', '2021-08-21 20:00:42', '2021-10-04 17:56:17', '1', '0'),
(9, 2, 8, 0, 'RM', 'TanushriPointo2', 'Kanu', 'tanushri2@gmail.com', 0, '', 'M', 'Married', '2004-08-18', '', '999999999999', '888888888888', 'somdeepalt@gmail.com', '', '123456', '34 GM Road; \nNear Senpally Auto Stand( SBI BANK)\nBehind New House\nBehala', 101, 41, 5583, '700034', '16296326857634.jpg', NULL, '{\"email_notify\":false,\"sms_notify\":false,\"email_on_new_notify\":false,\"email_on_direcr_msg\":false,\"email_on_add_cnction\":false,\"escalate_email_on_new_order\":false,\"escalate_email_on_new_member_approval\":false,\"escalate_email_on_member_registration\":false}', 'N', '2021-10-04 18:00:06', 'Y', '2021-08-21 20:00:42', '2021-10-04 17:47:14', '1', '0'),
(10, 2, 0, 0, 'RM', 'TanushriPointo3', 'Kanu', 'tanushri3@gmail.com', 0, '', 'M', 'Married', '1980-08-18', '', '999999999999', '888888888888', 'somdeepalt@gmail.com', '', '123456', '34 GM Road; \nNear Senpally Auto Stand( SBI BANK)\nBehind New House\nBehala', 101, 41, 5583, '700034', '16296326857634.jpg', NULL, '{\"email_notify\":false,\"sms_notify\":false,\"email_on_new_notify\":false,\"email_on_direcr_msg\":false,\"email_on_add_cnction\":false,\"escalate_email_on_new_order\":false,\"escalate_email_on_new_member_approval\":false,\"escalate_email_on_member_registration\":false}', 'N', '2021-09-15 15:48:12', 'Y', '2021-08-21 20:00:42', '2021-10-04 17:55:41', '1', '0'),
(11, 5, 13, 0, 'RM', 'Tanushri 4', 'Kanu4', 'tanushri4@gmail.com', 0, '', 'M', 'Married', '1980-08-18', '', '999999999999', '888888888888', 'somdeepalt@gmail.com', '', '123456', '34 GM Road; \nNear Senpally Auto Stand( SBI BANK)\nBehind New House\nBehala', 101, 41, 5583, '700034', '16296326857634.jpg', NULL, '{\"email_notify\":false,\"sms_notify\":false,\"email_on_new_notify\":false,\"email_on_direcr_msg\":false,\"email_on_add_cnction\":false,\"escalate_email_on_new_order\":false,\"escalate_email_on_new_member_approval\":false,\"escalate_email_on_member_registration\":false}', 'N', '2021-09-15 15:48:12', 'Y', '2021-08-21 20:00:42', '2021-08-22 13:52:16', '1', '0'),
(12, 5, 13, 0, 'RM', 'Tanushri 5', 'Kanu5', 'tanushri5@gmail.com', 0, '', 'M', 'Married', '1980-08-18', '', '999999999999', '888888888888', 'somdeepalt@gmail.com', '', '123456', '34 GM Road; \nNear Senpally Auto Stand( SBI BANK)\nBehind New House\nBehala', 101, 41, 5583, '700034', '16296326857634.jpg', NULL, '{\"email_notify\":false,\"sms_notify\":false,\"email_on_new_notify\":false,\"email_on_direcr_msg\":false,\"email_on_add_cnction\":false,\"escalate_email_on_new_order\":false,\"escalate_email_on_new_member_approval\":false,\"escalate_email_on_member_registration\":false}', 'N', '2021-09-15 15:48:12', 'Y', '2021-08-21 20:00:42', '2021-08-22 13:52:16', '1', '0'),
(13, 5, 0, 3, 'RM', 'Joydeep-A', 'Kanu', 'joydeep@gmail.com', 0, '', 'F', '', '2010-01-01', '', '', '', '', '', '123456', '', 0, 0, 0, '', NULL, NULL, NULL, 'Y', '2021-10-28 18:16:51', 'Y', '2021-10-02 15:40:28', '2021-10-04 17:53:40', '1', '0'),
(14, 5, 7, 0, 'RM', 'Subham', 'Gupta', 'subham@gmail.com', 0, '', 'M', '', '1999-08-18', NULL, NULL, NULL, NULL, NULL, '123456', '', 0, 0, 0, '', '1635777977.png', NULL, NULL, 'N', NULL, 'Y', '2021-10-02 18:47:03', '2021-11-01 15:46:17', '1', '0'),
(17, 1, 0, 4, 'RM', 'Swadhin', 'Das', 'swadhin@gmail.com', 0, NULL, 'M', '', '1980-07-18', NULL, NULL, NULL, NULL, NULL, '123456', NULL, 0, 0, 0, NULL, NULL, NULL, NULL, 'Y', '2021-10-04 20:09:52', 'Y', '2021-10-04 18:23:11', NULL, '1', '0'),
(18, 1, 17, 0, 'RM', 'Amiburo', 'Shau', 'amit@gmaail.com', 0, '', 'M', 'Married', '1930-10-01', '', '', '', '', '', '123456', '', 14, 290, 0, '', NULL, NULL, NULL, 'N', '2021-10-04 20:10:37', 'Y', '2021-10-04 18:36:13', '2021-10-04 20:02:24', '1', '0'),
(19, 5, 0, 0, 'RM', 'ew', 'ewe', 'admineee@gmail.com', 0, NULL, 'M', '', '2021-10-11', NULL, NULL, NULL, NULL, NULL, '123456', NULL, 0, 0, 0, NULL, NULL, NULL, NULL, 'N', NULL, 'Y', '2021-10-11 11:15:19', NULL, '1', '0'),
(20, 0, 0, 0, 'CM', 'rer', '', 'adminrr@gmail.com', 0, NULL, '', '', NULL, NULL, NULL, NULL, NULL, NULL, '123456', NULL, 0, 0, 0, NULL, NULL, NULL, NULL, 'N', NULL, 'Y', '2021-10-11 11:16:10', NULL, '1', '0'),
(21, 1, 0, 0, 'RM', 'feerer', 'rerer', 'admirrrn@gmail.com', 0, NULL, 'F', '', '2021-10-10', NULL, NULL, NULL, NULL, NULL, '123456', NULL, 0, 0, 0, NULL, NULL, NULL, NULL, 'N', NULL, 'N', '2021-10-11 11:16:39', NULL, '1', '0'),
(22, 5, 7, 0, 'RM', 'Pranay', 'Gupta', 'pranay@gmail.com', 0, '', 'M', '', '1999-08-18', NULL, NULL, NULL, NULL, NULL, '123456', '', 0, 0, 0, '', '1638894649.png', '1638981987.png', '{\"email_notify\":true,\"sms_notify\":false,\"email_on_new_notify\":false,\"email_on_direcr_msg\":false,\"email_on_add_cnction\":false,\"escalate_email_on_new_order\":false,\"escalate_email_on_new_member_approval\":false,\"escalate_email_on_member_registration\":false}', 'N', NULL, 'Y', '2021-10-02 18:47:03', '2021-12-07 17:30:49', '1', '0'),
(23, 0, 0, 0, 'CM', 'monta church', '', 'montachurch@gmail.com', 0, NULL, '', '', NULL, NULL, NULL, NULL, NULL, NULL, '123456', NULL, 0, 0, 0, NULL, NULL, NULL, NULL, 'N', NULL, 'Y', '2021-11-16 16:28:41', NULL, '1', '0'),
(25, 0, 0, 0, 'CM', 'Bassicalla Church', '', 'basicallachrch@gmail.com', 2, '', '', '', '2021-12-07', 'Somdeep Kanu', '986745896', '878887878878', 'church@ggmail.com', 'http://www.basilicachurch.com', '123456', 'St mark Street', 13, 248, 6559, '700036', '1639405695.png', NULL, '{\"email_notify\":true,\"sms_notify\":true,\"email_on_new_notify\":true,\"email_on_direcr_msg\":true,\"email_on_add_cnction\":false,\"escalate_email_on_new_order\":true,\"escalate_email_on_new_member_approval\":true,\"escalate_email_on_member_registration\":false}', 'N', NULL, 'Y', '2021-12-13 15:26:13', '2021-12-13 15:28:15', '1', '0'),
(26, 25, 0, 2, 'RM', 'Somdeep', 'Kanu', 'somdeep123u@gmail.com', 0, '', 'M', '', '1980-08-20', NULL, NULL, NULL, NULL, NULL, '123456', '', 0, 0, 0, '', '1639406117.png', '1639407212.png', NULL, 'Y', '2021-12-13 15:58:22', 'Y', '2021-12-13 15:34:02', '2021-12-13 15:35:17', '1', '0'),
(27, 25, 26, 0, 'RM', 'Sohalia', 'Kanu', 'sohaliakanu123@gmail.com', 0, '', 'F', '', '2000-01-05', NULL, NULL, NULL, NULL, NULL, '123456', '', 0, 0, 0, '', '1639406345.png', '1639411786.png', NULL, 'N', NULL, 'Y', '2021-12-13 15:37:26', '2021-12-13 15:39:05', '1', '0');

-- --------------------------------------------------------

--
-- Table structure for table `tn_member_friends`
--

CREATE TABLE `tn_member_friends` (
  `id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL DEFAULT 0,
  `friend_id` int(11) NOT NULL DEFAULT 0,
  `request_status` enum('1','2','3','4') NOT NULL DEFAULT '1' COMMENT '1: Request Send,2: Added As Friend,3: Remove From Suggestion,4: Delete From Friend',
  `request_date` datetime DEFAULT NULL,
  `remove_date` datetime DEFAULT NULL,
  `confirm_date` datetime DEFAULT NULL,
  `deletion_date` datetime DEFAULT NULL,
  `deleted` enum('0','1') NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tn_member_friends`
--

INSERT INTO `tn_member_friends` (`id`, `member_id`, `friend_id`, `request_status`, `request_date`, `remove_date`, `confirm_date`, `deletion_date`, `deleted`) VALUES
(1, 7, 6, '2', '2021-10-04 20:34:30', NULL, '2021-10-04 20:35:42', NULL, '0'),
(2, 6, 8, '3', '2021-10-04 20:37:19', '2021-10-04 20:37:34', NULL, NULL, '0'),
(3, 8, 6, '2', '2021-10-04 20:38:19', NULL, '2021-10-04 20:39:59', NULL, '0'),
(4, 22, 14, '2', '2021-12-06 16:08:26', NULL, '2021-12-06 16:10:20', NULL, '0'),
(5, 5, 22, '2', '2021-12-06 16:20:48', NULL, '2021-12-06 16:23:39', NULL, '0'),
(6, 5, 7, '2', '2021-12-06 16:20:52', NULL, '2022-01-05 16:43:22', NULL, '0'),
(7, 5, 13, '1', '2021-12-06 16:20:59', NULL, NULL, NULL, '0'),
(8, 5, 3, '1', '2021-12-06 16:22:00', NULL, NULL, NULL, '0'),
(9, 25, 3, '1', '2021-12-13 15:31:16', NULL, '2021-12-13 17:25:09', NULL, '0'),
(10, 27, 26, '2', '2021-12-13 15:41:24', NULL, '2021-12-13 15:52:39', NULL, '0'),
(11, 25, 22, '1', '2021-12-13 15:55:13', NULL, '2022-01-14 14:30:20', '2022-01-14 14:29:52', '0'),
(12, 25, 27, '1', '2021-12-13 15:55:17', NULL, '2021-12-13 17:38:34', NULL, '0'),
(13, 22, 27, '2', '2021-12-13 17:39:47', NULL, '2021-12-13 17:41:32', NULL, '0'),
(14, 13, 27, '2', '2021-12-13 17:40:17', NULL, '2021-12-13 17:41:16', NULL, '0'),
(15, 7, 27, '2', '2021-12-13 17:40:52', NULL, '2021-12-13 17:41:30', NULL, '0'),
(16, 8, 25, '2', '2022-01-14 14:33:56', NULL, '2022-01-14 14:36:50', NULL, '0'),
(17, 8, 22, '1', '2022-01-14 14:34:07', NULL, NULL, NULL, '0'),
(18, 5, 25, '2', '2022-01-14 14:35:12', NULL, '2022-01-14 14:36:55', NULL, '0'),
(19, 13, 25, '2', '2022-01-14 14:35:34', NULL, '2022-01-14 14:36:45', NULL, '0');

-- --------------------------------------------------------

--
-- Table structure for table `tn_member_level`
--

CREATE TABLE `tn_member_level` (
  `id` int(11) NOT NULL,
  `course_id` int(11) NOT NULL,
  `task_level` int(11) NOT NULL,
  `member_id` int(11) NOT NULL,
  `promote_date` datetime DEFAULT NULL,
  `remove_date` datetime DEFAULT NULL,
  `status` enum('0','1') NOT NULL DEFAULT '1',
  `no_of_badge` int(4) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tn_member_level`
--

INSERT INTO `tn_member_level` (`id`, `course_id`, `task_level`, `member_id`, `promote_date`, `remove_date`, `status`, `no_of_badge`) VALUES
(1, 1, 1, 14, '2021-10-06 17:23:09', '2021-12-27 16:27:47', '1', 15),
(2, 1, 1, 22, '2021-11-01 14:52:52', NULL, '1', 0),
(25, 1, 2, 14, '2021-11-02 16:40:09', '2021-12-27 16:27:47', '1', 10),
(26, 1, 3, 14, '2021-11-02 16:40:40', '2021-12-27 16:27:47', '1', 25),
(27, 2, 1, 14, NULL, '2021-12-27 16:27:47', '1', 10),
(28, 2, 2, 14, '2021-11-02 16:42:11', '2021-12-27 16:27:47', '1', 20),
(29, 2, 3, 14, '2021-11-02 18:05:54', '2021-12-27 16:27:47', '1', 25),
(30, 2, 4, 14, '2021-11-02 18:06:16', '2021-12-27 16:27:47', '1', 20),
(31, 2, 5, 14, '2021-11-02 18:06:25', '2021-12-27 16:27:47', '1', 5),
(32, 2, 6, 14, '2021-11-02 18:06:32', '2021-12-27 16:27:47', '1', 10),
(33, 3, 1, 15, NULL, NULL, '1', 0),
(34, 3, 1, 14, NULL, '2021-12-27 16:27:47', '1', 15),
(35, 3, 2, 14, '2021-11-05 14:04:02', '2021-12-27 16:27:47', '1', 20),
(36, 3, 3, 14, '2021-11-05 14:04:12', '2021-12-27 16:27:47', '1', 20),
(37, 3, 4, 14, '2021-11-05 14:04:20', '2021-12-27 16:27:47', '1', 10),
(38, 3, 5, 14, '2021-11-05 14:04:27', '2021-12-27 16:27:47', '1', 15),
(39, 3, 6, 14, '2021-11-05 14:04:34', '2021-12-27 16:27:47', '1', 15),
(40, 4, 1, 14, NULL, '2021-12-27 16:27:47', '1', 10),
(41, 4, 2, 14, '2021-11-05 14:05:00', '2021-12-27 16:27:47', '1', 15),
(43, 4, 3, 14, '2021-11-05 14:06:13', '2021-12-27 16:27:47', '1', 15),
(44, 4, 4, 14, '2021-11-05 14:06:35', '2021-12-27 16:27:47', '1', 15),
(45, 4, 5, 14, '2021-11-05 14:06:44', '2021-12-27 16:27:47', '1', 10),
(46, 4, 6, 14, '2021-11-05 14:07:04', '2021-12-27 16:27:47', '1', 20),
(48, 4, 999, 14, '2021-11-05 14:08:52', '2021-12-27 16:27:47', '1', 0),
(49, 1, 1, 27, '2021-12-13 16:21:48', NULL, '1', 25),
(51, 1, 2, 27, '2021-12-13 17:07:55', NULL, '1', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tn_member_timeline`
--

CREATE TABLE `tn_member_timeline` (
  `id` int(11) NOT NULL,
  `post_id` int(11) NOT NULL DEFAULT 0,
  `from_member_id` int(11) NOT NULL DEFAULT 0,
  `to_member_id` int(11) NOT NULL DEFAULT 0,
  `create_date` datetime DEFAULT NULL,
  `status` enum('S','H') NOT NULL DEFAULT 'S' COMMENT 'S:Show in timeline; H:Hide for time',
  `deleted` enum('0','1') NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tn_member_timeline`
--

INSERT INTO `tn_member_timeline` (`id`, `post_id`, `from_member_id`, `to_member_id`, `create_date`, `status`, `deleted`) VALUES
(1, 1, 7, 7, '2022-01-03 08:21:35', 'S', '0'),
(2, 1, 7, 27, '2022-01-03 08:21:35', 'S', '0'),
(3, 1, 7, 6, '2022-01-03 08:21:35', 'S', '0'),
(4, 2, 6, 6, '2022-01-03 15:38:27', 'S', '0'),
(5, 2, 6, 8, '2022-01-03 15:38:27', 'S', '0'),
(6, 2, 6, 7, '2022-01-03 15:38:27', 'S', '0'),
(7, 3, 7, 7, '2022-01-03 15:46:05', 'S', '0'),
(8, 4, 7, 7, '2022-01-03 15:46:39', 'S', '0'),
(9, 5, 7, 7, '2022-01-03 15:49:09', 'S', '0'),
(10, 6, 7, 7, '2022-01-03 15:52:25', 'S', '0'),
(11, 7, 7, 7, '2022-01-04 14:57:36', 'H', '0'),
(12, 8, 7, 7, '2022-01-04 16:55:13', 'S', '0'),
(13, 8, 7, 27, '2022-01-04 16:55:13', 'S', '0'),
(14, 8, 7, 6, '2022-01-04 16:55:13', 'S', '0'),
(15, 9, 7, 7, '2022-01-05 16:40:55', 'S', '0'),
(16, 9, 7, 27, '2022-01-05 16:40:55', 'S', '0'),
(17, 9, 7, 6, '2022-01-05 16:40:55', 'S', '0'),
(18, 10, 7, 7, '2022-01-06 17:02:45', 'S', '0'),
(19, 11, 7, 7, '2022-01-17 17:00:08', 'S', '0'),
(20, 11, 7, 5, '2022-01-17 17:00:08', 'S', '0'),
(21, 11, 7, 27, '2022-01-17 17:00:08', 'S', '0');

-- --------------------------------------------------------

--
-- Table structure for table `tn_post`
--

CREATE TABLE `tn_post` (
  `id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL,
  `post` mediumtext DEFAULT NULL,
  `create_date` datetime DEFAULT NULL,
  `update_date` datetime DEFAULT NULL,
  `status` enum('0','1') NOT NULL DEFAULT '1',
  `deleted` enum('0','1') NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tn_post`
--

INSERT INTO `tn_post` (`id`, `member_id`, `post`, `create_date`, `update_date`, `status`, `deleted`) VALUES
(1, 7, 'Test Post 1', '2022-01-03 08:21:35', NULL, '1', '0'),
(2, 6, 'post from tanushri kanu', '2022-01-03 15:38:27', NULL, '1', '0'),
(3, 7, 'post 2 from somdeep', '2022-01-03 15:46:05', NULL, '1', '0'),
(4, 7, 'post 3 from somdeep', '2022-01-03 15:46:39', NULL, '1', '0'),
(5, 7, '', '2022-01-03 15:49:09', NULL, '1', '0'),
(6, 7, 'somdeep 4', '2022-01-03 15:52:25', NULL, '1', '0'),
(7, 7, '6 images', '2022-01-04 14:57:36', NULL, '1', '0'),
(8, 7, 'anirban comment', '2022-01-04 16:55:13', NULL, '1', '0'),
(9, 7, 'binata kanu comment', '2022-01-05 16:40:55', NULL, '1', '0'),
(10, 7, 'today is thursday', '2022-01-06 17:02:45', NULL, '1', '0'),
(11, 7, 'from my profile red karishma', '2022-01-17 17:00:08', NULL, '1', '0');

-- --------------------------------------------------------

--
-- Table structure for table `tn_post_comments`
--

CREATE TABLE `tn_post_comments` (
  `id` int(11) NOT NULL,
  `post_id` int(11) NOT NULL DEFAULT 0,
  `member_id` int(11) NOT NULL DEFAULT 0,
  `member_comment` mediumtext DEFAULT NULL,
  `create_date` datetime DEFAULT NULL,
  `deleted` enum('0','1') NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tn_post_comments`
--

INSERT INTO `tn_post_comments` (`id`, `post_id`, `member_id`, `member_comment`, `create_date`, `deleted`) VALUES
(1, 9, 7, 'my first comment1', '2022-01-11 16:03:19', '0'),
(2, 9, 7, 'my first comment2', '2022-01-11 16:03:31', '0'),
(3, 9, 7, 'my first comment3', '2022-01-11 16:03:37', '0'),
(4, 9, 7, 'my first comment4', '2022-01-11 16:03:46', '0'),
(5, 9, 7, 'my first comment5', '2022-01-14 12:17:53', '0'),
(6, 11, 7, 'my comments lal1', '2022-01-17 17:00:35', '0'),
(7, 11, 7, 'my comments lal2', '2022-01-17 17:00:40', '0'),
(8, 11, 7, 'my comments lal3', '2022-01-17 17:01:00', '0'),
(9, 11, 7, 'my comments lal4', '2022-01-17 17:01:13', '0'),
(10, 11, 7, 'my comments lal5', '2022-01-17 17:01:16', '0');

-- --------------------------------------------------------

--
-- Table structure for table `tn_post_file`
--

CREATE TABLE `tn_post_file` (
  `id` int(11) NOT NULL,
  `post_id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL,
  `file_original_name` varchar(100) NOT NULL,
  `file_name` varchar(25) DEFAULT NULL,
  `file_size` varchar(15) DEFAULT NULL,
  `file_type` varchar(15) DEFAULT NULL,
  `create_date` datetime DEFAULT NULL,
  `deleted` enum('0','1') NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tn_post_file`
--

INSERT INTO `tn_post_file` (`id`, `post_id`, `member_id`, `file_original_name`, `file_name`, `file_size`, `file_type`, `create_date`, `deleted`) VALUES
(1, 1, 7, '1.jpg', '16411944958569.jpg', '5313', 'image/jpeg', '2022-01-03 08:21:35', '0'),
(2, 1, 7, '2.jpg', '16411944959454.jpg', '61123', 'image/jpeg', '2022-01-03 08:21:35', '0'),
(3, 1, 7, '3.jpg', '1641194495999.jpg', '83154', 'image/jpeg', '2022-01-03 08:21:35', '0'),
(4, 2, 6, '4.jpg', '16412207081842.jpg', '117385', 'image/jpeg', '2022-01-03 15:38:27', '0'),
(5, 2, 6, '5.jpg', '16412207086446.jpg', '7019', 'image/jpeg', '2022-01-03 15:38:27', '0'),
(6, 2, 6, '6.jpg', '1641220708816.jpg', '7289', 'image/jpeg', '2022-01-03 15:38:27', '0'),
(7, 2, 6, '7.jpg', '16412207089243.jpg', '67612', 'image/jpeg', '2022-01-03 15:38:27', '0'),
(8, 3, 7, '4037548672_c11b2352b6.jpg', '16412211656067.jpg', '62714', 'image/jpeg', '2022-01-03 15:46:05', '0'),
(9, 4, 7, 'cb7b0446-8db4-4a59-b365-2595dc8a09b3.jpg', '1641221199317.jpg', '22728', 'image/jpeg', '2022-01-03 15:46:39', '0'),
(10, 5, 7, 'kar2a.jpg', '16412213497444.jpg', '108097', 'image/jpeg', '2022-01-03 15:49:09', '0'),
(11, 5, 7, 'kar13d.jpg', '16412213498058.jpg', '40474', 'image/jpeg', '2022-01-03 15:49:09', '0'),
(12, 6, 7, '4037548672_c11b2352b6.jpg', '16412215460989.jpg', '62714', 'image/jpeg', '2022-01-03 15:52:25', '0'),
(13, 6, 7, '1.jpg', '16412215461962.jpg', '5313', 'image/jpeg', '2022-01-03 15:52:25', '0'),
(14, 7, 7, '1.jpg', '1641304656335.jpg', '5313', 'image/jpeg', '2022-01-04 14:57:36', '0'),
(15, 7, 7, '2.jpg', '16413046564382.jpg', '61123', 'image/jpeg', '2022-01-04 14:57:36', '0'),
(16, 7, 7, '3.jpg', '16413046564937.jpg', '83154', 'image/jpeg', '2022-01-04 14:57:36', '0'),
(17, 7, 7, '04cc6fc6-4172-426b-86a5-10dbba62c22c.jpg', '16413046565605.jpg', '55153', 'image/jpeg', '2022-01-04 14:57:36', '0'),
(18, 7, 7, '4.jpg', '16413046566379.jpg', '117385', 'image/jpeg', '2022-01-04 14:57:36', '0'),
(19, 7, 7, '5.jpg', '16413046568467.jpg', '7019', 'image/jpeg', '2022-01-04 14:57:36', '0'),
(20, 8, 7, '1.jpg', '16413117147997.jpg', '5313', 'image/jpeg', '2022-01-04 16:55:13', '0'),
(21, 8, 7, '2.jpg', '16413117160022.jpg', '61123', 'image/jpeg', '2022-01-04 16:55:13', '0'),
(22, 8, 7, '3.jpg', '16413117161437.jpg', '83154', 'image/jpeg', '2022-01-04 16:55:13', '0'),
(23, 8, 7, '04cc6fc6-4172-426b-86a5-10dbba62c22c.jpg', '16413117164305.jpg', '55153', 'image/jpeg', '2022-01-04 16:55:13', '0'),
(24, 8, 7, '4.jpg', '16413117169406.jpg', '117385', 'image/jpeg', '2022-01-04 16:55:13', '0'),
(25, 8, 7, '5.jpg', '16413117173517.jpg', '7019', 'image/jpeg', '2022-01-04 16:55:13', '0'),
(26, 9, 7, '5.jpg', '16413972561454.jpg', '7019', 'image/jpeg', '2022-01-05 16:40:55', '0'),
(27, 9, 7, '6.jpg', '16413972563278.jpg', '7289', 'image/jpeg', '2022-01-05 16:40:55', '0'),
(28, 9, 7, '7.jpg', '16413972565253.jpg', '67612', 'image/jpeg', '2022-01-05 16:40:55', '0'),
(29, 10, 7, '12.jpg', '16414849661534.jpg', '39441', 'image/jpeg', '2022-01-06 17:02:45', '0'),
(30, 10, 7, '14.jpg', '164148496632.jpg', '87732', 'image/jpeg', '2022-01-06 17:02:45', '0'),
(31, 10, 7, '4037548672_c11b2352b6.jpg', '1641484966391.jpg', '62714', 'image/jpeg', '2022-01-06 17:02:45', '0'),
(32, 11, 7, '3.jpg', '16424352095056.jpg', '83154', 'image/jpeg', '2022-01-17 17:00:08', '0'),
(33, 11, 7, '7.jpg', '16424352097065.jpg', '67612', 'image/jpeg', '2022-01-17 17:00:08', '0'),
(34, 11, 7, '7ee377d4-82ec-4b2e-8f5e-526a1ab96e62.jpg', '16424352097713.jpg', '66916', 'image/jpeg', '2022-01-17 17:00:08', '0'),
(35, 11, 7, 'karishma_kapoor_011_1024x768_hyte.jpg', '16424352098394.jpg', '72862', 'image/jpeg', '2022-01-17 17:00:08', '0'),
(36, 11, 7, 'wp4101761.jpg', '16424352099059.jpg', '71451', 'image/jpeg', '2022-01-17 17:00:08', '0');

-- --------------------------------------------------------

--
-- Table structure for table `tn_post_like`
--

CREATE TABLE `tn_post_like` (
  `id` int(11) NOT NULL,
  `post_id` int(11) NOT NULL DEFAULT 0,
  `member_id` int(11) NOT NULL DEFAULT 0,
  `create_date` datetime DEFAULT NULL,
  `deleted` enum('0','1') NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tn_post_like`
--

INSERT INTO `tn_post_like` (`id`, `post_id`, `member_id`, `create_date`, `deleted`) VALUES
(1, 9, 7, '2022-01-14 12:02:47', '0'),
(2, 9, 6, '2021-08-11 15:32:26', '0'),
(3, 9, 27, '2021-10-07 20:56:07', '0'),
(7, 10, 7, '2022-01-11 15:05:31', '0'),
(8, 8, 7, '2022-01-06 17:17:58', '0'),
(9, 2, 7, '2022-01-14 12:32:58', '0'),
(10, 11, 7, '2022-01-17 17:00:21', '0'),
(11, 1, 7, '2022-01-17 17:16:05', '1');

-- --------------------------------------------------------

--
-- Table structure for table `tn_post_tag_friend`
--

CREATE TABLE `tn_post_tag_friend` (
  `id` int(11) NOT NULL,
  `post_id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL,
  `tagged_member_id` int(11) NOT NULL,
  `create_date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tn_post_tag_friend`
--

INSERT INTO `tn_post_tag_friend` (`id`, `post_id`, `member_id`, `tagged_member_id`, `create_date`) VALUES
(1, 1, 7, 27, '2022-01-03 08:21:35'),
(2, 1, 7, 6, '2022-01-03 08:21:35'),
(3, 2, 6, 8, '2022-01-03 15:38:27'),
(4, 2, 6, 7, '2022-01-03 15:38:27'),
(5, 8, 7, 27, '2022-01-04 16:55:13'),
(6, 8, 7, 6, '2022-01-04 16:55:13'),
(7, 9, 7, 27, '2022-01-05 16:40:55'),
(8, 9, 7, 6, '2022-01-05 16:40:55'),
(9, 11, 7, 5, '2022-01-17 17:00:08'),
(10, 11, 7, 27, '2022-01-17 17:00:08');

-- --------------------------------------------------------

--
-- Table structure for table `tn_streaming_member`
--

CREATE TABLE `tn_streaming_member` (
  `id` int(11) NOT NULL,
  `stream_video_id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL,
  `join_date` datetime DEFAULT NULL,
  `leave_date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tn_streaming_member`
--

INSERT INTO `tn_streaming_member` (`id`, `stream_video_id`, `member_id`, `join_date`, `leave_date`) VALUES
(1, 11, 14, '2021-10-28 18:04:07', NULL),
(2, 11, 22, '2021-11-05 18:23:08', '2021-12-12 16:54:17'),
(3, 14, 27, '2021-12-13 16:25:40', '2021-12-13 17:08:16');

-- --------------------------------------------------------

--
-- Table structure for table `tn_support_ticket`
--

CREATE TABLE `tn_support_ticket` (
  `id` int(21) NOT NULL,
  `parent_id` int(21) NOT NULL DEFAULT 0,
  `response_from` int(11) NOT NULL DEFAULT 0,
  `response_to` int(11) NOT NULL DEFAULT 0,
  `subject` text DEFAULT NULL,
  `description` text DEFAULT NULL,
  `created_on` datetime DEFAULT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tn_task_level`
--

CREATE TABLE `tn_task_level` (
  `id` int(11) NOT NULL,
  `course_id` int(11) NOT NULL,
  `task_level` smallint(4) DEFAULT NULL,
  `church_id` int(11) NOT NULL,
  `church_admin_id` int(11) NOT NULL,
  `create_date` datetime DEFAULT NULL,
  `update_date` datetime DEFAULT NULL,
  `status` enum('0','1') NOT NULL DEFAULT '1',
  `deleted` enum('0','1') NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tn_task_level`
--

INSERT INTO `tn_task_level` (`id`, `course_id`, `task_level`, `church_id`, `church_admin_id`, `create_date`, `update_date`, `status`, `deleted`) VALUES
(1, 2, 2, 5, 7, '2021-10-08 18:24:21', '2021-10-11 09:34:13', '1', '0'),
(3, 2, 2, 5, 13, '2021-10-08 18:53:25', '2021-10-11 11:06:02', '1', '0'),
(4, 1, 1, 5, 7, '2021-10-09 08:44:44', '2021-12-12 16:46:34', '1', '0'),
(5, 1, 1, 5, 13, '2021-10-09 08:46:26', '2021-11-29 16:54:43', '1', '0'),
(6, 1, 2, 5, 7, '2021-10-13 08:32:41', '2021-10-13 08:33:27', '1', '0'),
(293, 1, 2, 5, 13, '2021-11-29 16:50:16', '2021-11-29 16:52:24', '1', '0'),
(294, 1, 3, 5, 7, '2021-11-29 16:58:21', '2021-11-29 16:59:08', '1', '0'),
(295, 1, 1, 25, 26, '2021-12-13 16:12:50', '2021-12-13 16:19:56', '1', '0');

-- --------------------------------------------------------

--
-- Table structure for table `tn_task_level_course`
--

CREATE TABLE `tn_task_level_course` (
  `id` int(11) NOT NULL,
  `course_name` varchar(100) DEFAULT NULL,
  `course_description` text DEFAULT NULL,
  `number_of_level` smallint(4) NOT NULL DEFAULT 6,
  `create_date` datetime DEFAULT NULL,
  `update_date` datetime DEFAULT NULL,
  `status` enum('0','1') NOT NULL DEFAULT '1',
  `deleted` enum('0','1') NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tn_task_level_course`
--

INSERT INTO `tn_task_level_course` (`id`, `course_name`, `course_description`, `number_of_level`, `create_date`, `update_date`, `status`, `deleted`) VALUES
(1, '1st Semester', '1st Semester Desc', 3, '2021-10-06 20:56:07', NULL, '1', '0'),
(2, '2nd Semester', '2nd Semester Desc', 6, '2021-10-07 20:56:07', NULL, '1', '0'),
(3, '3rd Semester', '3rd Semester Desc', 6, '2021-10-07 21:23:07', NULL, '1', '0'),
(4, '4th Semester', '4th Semester Desc', 6, '2021-10-07 21:23:07', NULL, '1', '0');

-- --------------------------------------------------------

--
-- Table structure for table `tn_task_level_stream_video`
--

CREATE TABLE `tn_task_level_stream_video` (
  `id` int(11) NOT NULL,
  `task_level_id` int(11) NOT NULL,
  `video_title` varchar(100) DEFAULT NULL,
  `start_time` datetime DEFAULT NULL,
  `end_time` datetime DEFAULT NULL,
  `description` mediumtext DEFAULT NULL,
  `video_name` varchar(255) DEFAULT NULL,
  `video_size` varchar(25) DEFAULT NULL,
  `video_type` varchar(15) DEFAULT NULL,
  `create_date` datetime DEFAULT NULL,
  `update_date` datetime DEFAULT NULL,
  `status` enum('0','1') NOT NULL DEFAULT '1',
  `is_live` enum('Y','N') NOT NULL DEFAULT 'N',
  `deleted` enum('0','1') NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tn_task_level_stream_video`
--

INSERT INTO `tn_task_level_stream_video` (`id`, `task_level_id`, `video_title`, `start_time`, `end_time`, `description`, `video_name`, `video_size`, `video_type`, `create_date`, `update_date`, `status`, `is_live`, `deleted`) VALUES
(1, 1, 'SomAdmin Title1', '2021-10-21 12:13:00', NULL, 'SomAdmin Title1 Desc', NULL, NULL, NULL, '2021-10-11 09:15:17', NULL, '1', 'N', '0'),
(2, 1, 'SomAdmin Title2e', '2021-10-28 12:13:00', NULL, 'SomAdmin Title1 desc', NULL, NULL, NULL, '2021-10-11 09:34:13', NULL, '1', 'N', '0'),
(3, 4, 'SomAdmin Title1 C1l1', '2021-10-09 12:14:00', NULL, 'SomAdmin Title1 C1l1 desc', NULL, NULL, NULL, '2021-10-09 08:44:44', NULL, '1', 'N', '0'),
(4, 5, 'PiuAdmin Title1 C1l1', '2021-10-20 12:16:00', NULL, 'piuAdmin Title1 C1l1', NULL, NULL, NULL, '2021-10-09 08:46:26', NULL, '1', 'N', '0'),
(6, 3, 'piu Admin Stream 1', '2021-10-14 14:35:00', NULL, 'rpiu Admin Sreat 1', NULL, NULL, NULL, '2021-10-11 11:06:02', NULL, '1', 'N', '0'),
(10, 4, 'Stream Schedule 2', '2021-11-25 21:18:00', NULL, 'Stream Schedule 2 xxx', NULL, NULL, NULL, '2021-11-02 17:57:44', NULL, '1', 'N', '0'),
(11, 4, 'Video 4Title', '2021-10-16 22:07:00', NULL, 'dsdsd', NULL, NULL, NULL, '2021-10-16 18:37:18', NULL, '1', 'N', '0'),
(12, 4, 'dsd', '2021-11-24 22:05:00', NULL, 'dsd', NULL, NULL, NULL, '2021-11-24 18:29:38', NULL, '1', 'N', '0'),
(13, 4, 'fd', '1970-01-01 01:00:00', NULL, 'fd', NULL, NULL, NULL, '2021-11-24 18:29:48', NULL, '1', 'N', '0'),
(14, 295, 'My First edited Streaming Schedule', '2021-12-12 20:42:00', NULL, 'My First Streaming Schedule descipriond', NULL, NULL, NULL, '2021-12-13 16:15:03', NULL, '1', 'N', '0');

-- --------------------------------------------------------

--
-- Table structure for table `tn_task_level_video`
--

CREATE TABLE `tn_task_level_video` (
  `id` int(11) NOT NULL,
  `task_level_id` int(11) NOT NULL,
  `video_number` tinyint(4) NOT NULL,
  `video_name` varchar(255) DEFAULT NULL,
  `video_size` varchar(25) DEFAULT NULL,
  `video_type` varchar(15) DEFAULT NULL,
  `create_date` datetime DEFAULT NULL,
  `update_date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tn_task_level_video`
--

INSERT INTO `tn_task_level_video` (`id`, `task_level_id`, `video_number`, `video_name`, `video_size`, `video_type`, `create_date`, `update_date`) VALUES
(1, 1, 2, '16337103083842.mp4', '2107842', 'video/mp4', '2021-10-08 18:24:21', '2021-10-08 18:25:08'),
(2, 1, 3, '16337103542864.mp4', '75120426', 'video/mp4', '2021-10-08 18:25:55', NULL),
(4, 3, 2, '16337120054579.mp4', '2107842', 'video/mp4', '2021-10-08 18:53:25', NULL),
(5, 3, 1, '16337120511699.mp4', '75120426', 'video/mp4', '2021-10-08 18:54:11', NULL),
(6, 6, 1, '16341067616541.mp4', '2107842', 'video/mp4', '2021-10-13 08:32:42', NULL),
(7, 6, 2, '16341067855623.mp4', '75120426', 'video/mp4', '2021-10-13 08:33:06', NULL),
(8, 6, 3, '16341068080426.mp4', '161554111', 'video/mp4', '2021-10-13 08:33:42', NULL),
(9, 295, 1, '16394084132409.mp4', '2107842', 'video/mp4', '2021-12-13 16:13:33', NULL),
(10, 295, 2, '16394084404989.mp4', '161554111', 'video/mp4', '2021-12-13 16:14:06', NULL),
(11, 295, 3, '16394084656056.mp4', '75120426', 'video/mp4', '2021-12-13 16:14:26', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tn_task_level_video_viewed`
--

CREATE TABLE `tn_task_level_video_viewed` (
  `id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL,
  `task_level_video_id` int(11) NOT NULL,
  `video_viewed_time` varchar(10) NOT NULL DEFAULT '0',
  `is_full_viwed` enum('Y','N') NOT NULL DEFAULT 'N',
  `view_date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tn_task_level_video_viewed`
--

INSERT INTO `tn_task_level_video_viewed` (`id`, `member_id`, `task_level_video_id`, `video_viewed_time`, `is_full_viwed`, `view_date`) VALUES
(1, 14, 8, '25.323825', 'N', '2021-10-13 16:37:34'),
(2, 14, 6, '13.504', 'Y', '2021-10-13 16:38:00'),
(3, 27, 9, '13.504', 'Y', '2021-12-13 16:26:43'),
(4, 27, 10, '159.317333', 'Y', '2021-12-13 16:27:11'),
(5, 27, 11, '73.941333', 'Y', '2021-12-13 16:27:31');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `username` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `contact` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `gender` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `role_id` int(11) NOT NULL,
  `zipcode` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `dob` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `status` int(11) NOT NULL,
  `register_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `username`, `contact`, `address`, `gender`, `image`, `role_id`, `zipcode`, `dob`, `status`, `register_date`) VALUES
(1, 'Administrator', 'trustnetwork@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', 'Administrator', '9898989898', 'Maidan', 'Female', 'YADU_Logo.JPG', 1, '700001', '1990-08-03', 1, '2017-08-18 10:46:38'),
(4, 'Somdeep Kanu', 'somdeepkanu@ggmail.com', 'e10adc3949ba59abbe56e057f20f883e', 'som123', '9898989898', 'durga nagar asas', 'Male', 'slide_05.jpg', 2, '700002', '1990-08-03', 1, '2017-08-09 13:19:15');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_exam`
--
ALTER TABLE `tbl_exam`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_exam_given`
--
ALTER TABLE `tbl_exam_given`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_exam_given_answer`
--
ALTER TABLE `tbl_exam_given_answer`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_exam_question`
--
ALTER TABLE `tbl_exam_question`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tn_age_group`
--
ALTER TABLE `tn_age_group`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tn_group`
--
ALTER TABLE `tn_group`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tn_members`
--
ALTER TABLE `tn_members`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tn_member_friends`
--
ALTER TABLE `tn_member_friends`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tn_member_level`
--
ALTER TABLE `tn_member_level`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tn_member_timeline`
--
ALTER TABLE `tn_member_timeline`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tn_post`
--
ALTER TABLE `tn_post`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tn_post_comments`
--
ALTER TABLE `tn_post_comments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tn_post_file`
--
ALTER TABLE `tn_post_file`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tn_post_like`
--
ALTER TABLE `tn_post_like`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tn_post_tag_friend`
--
ALTER TABLE `tn_post_tag_friend`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tn_streaming_member`
--
ALTER TABLE `tn_streaming_member`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tn_support_ticket`
--
ALTER TABLE `tn_support_ticket`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tn_task_level`
--
ALTER TABLE `tn_task_level`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tn_task_level_course`
--
ALTER TABLE `tn_task_level_course`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tn_task_level_stream_video`
--
ALTER TABLE `tn_task_level_stream_video`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tn_task_level_video`
--
ALTER TABLE `tn_task_level_video`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tn_task_level_video_viewed`
--
ALTER TABLE `tn_task_level_video_viewed`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_exam`
--
ALTER TABLE `tbl_exam`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `tbl_exam_given`
--
ALTER TABLE `tbl_exam_given`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_exam_given_answer`
--
ALTER TABLE `tbl_exam_given_answer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tbl_exam_question`
--
ALTER TABLE `tbl_exam_question`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `tn_age_group`
--
ALTER TABLE `tn_age_group`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tn_group`
--
ALTER TABLE `tn_group`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `tn_members`
--
ALTER TABLE `tn_members`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `tn_member_friends`
--
ALTER TABLE `tn_member_friends`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `tn_member_level`
--
ALTER TABLE `tn_member_level`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=52;

--
-- AUTO_INCREMENT for table `tn_member_timeline`
--
ALTER TABLE `tn_member_timeline`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `tn_post`
--
ALTER TABLE `tn_post`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `tn_post_comments`
--
ALTER TABLE `tn_post_comments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `tn_post_file`
--
ALTER TABLE `tn_post_file`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT for table `tn_post_like`
--
ALTER TABLE `tn_post_like`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `tn_post_tag_friend`
--
ALTER TABLE `tn_post_tag_friend`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `tn_streaming_member`
--
ALTER TABLE `tn_streaming_member`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tn_support_ticket`
--
ALTER TABLE `tn_support_ticket`
  MODIFY `id` int(21) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tn_task_level`
--
ALTER TABLE `tn_task_level`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=296;

--
-- AUTO_INCREMENT for table `tn_task_level_course`
--
ALTER TABLE `tn_task_level_course`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tn_task_level_stream_video`
--
ALTER TABLE `tn_task_level_stream_video`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `tn_task_level_video`
--
ALTER TABLE `tn_task_level_video`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `tn_task_level_video_viewed`
--
ALTER TABLE `tn_task_level_video_viewed`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
